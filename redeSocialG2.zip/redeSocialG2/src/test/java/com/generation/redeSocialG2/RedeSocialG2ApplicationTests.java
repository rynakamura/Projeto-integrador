package com.generation.redeSocialG2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedeSocialG2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
